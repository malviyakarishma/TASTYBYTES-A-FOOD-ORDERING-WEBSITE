<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the connection file
include('connection.php');

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['user'];
    $password = $_POST['pass'];

    // Escape the input
    $name = stripslashes($name);
    $username = stripslashes($username);
    $password = stripslashes($password);
    $name = mysqli_real_escape_string($con, $name);
    $username = mysqli_real_escape_string($con, $username);
    $password = mysqli_real_escape_string($con, $password);

    // Check if the username already exists
    $stmt = $con->prepare("SELECT * FROM user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Username already taken!";
    } else {
        // Insert new user into the database
        $stmt = $con->prepare("INSERT INTO user (name, username, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $username, $password);

        if ($stmt->execute()) {
            header("Location: index.html");
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
