<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session at the beginning of the script
session_start();

include('connection.php');

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['user'];
    $password = $_POST['pass'];

    // Escape the input
    $username = stripslashes($username);
    $password = stripslashes($password);
    $username = mysqli_real_escape_string($con, $username);
    $password = mysqli_real_escape_string($con, $password);

    // Use prepared statements for better security
    $stmt = $con->prepare("SELECT * FROM user WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Check if user exists and password matches
    if ($user) {
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $user['name'];
        header("Location: home.php");
        exit();
    } else {
        echo("Invalid Username or Password !!!!");
    }
}
?>
